package loginproject.validation;

import javax.swing.*;
import java.awt.*;
  
class Nextpage extends JFrame
 {
   Nextpage()
  {
  setDefaultCloseOperation(javax.swing.
   WindowConstants.DISPOSE_ON_CLOSE);
  setTitle("Welcome");
  setSize(400, 200);
   }
  }